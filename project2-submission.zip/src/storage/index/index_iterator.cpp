/**
 * index_iterator.cpp
 */
#include <cassert>

#include "storage/index/index_iterator.h"

namespace bustub {

/*
 * NOTE: you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator() = default;

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BufferPoolManager *bpm, page_id_t page_id, int index)
    : buffer_pool_manager_(bpm), page_id_(page_id), index_(index), leaf_(nullptr) {
  if (page_id_ != INVALID_PAGE_ID) {
    Page *page = buffer_pool_manager_->FetchPage(page_id_);
    leaf_ = reinterpret_cast<LeafPage *>(page->GetData());
  }
}

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::~IndexIterator() {
  if (page_id_ != INVALID_PAGE_ID && buffer_pool_manager_ != nullptr) {
    buffer_pool_manager_->UnpinPage(page_id_, false);
  }
}  // NOLINT

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool { return page_id_ == INVALID_PAGE_ID; }

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> const MappingType & {
  // 返回当前叶子页中索引位置的键值对
  MappingType *array = reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf_) + LEAF_PAGE_HEADER_SIZE);
  return array[index_];
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & {
  index_++;
  // 如果超出当前叶子页的范围，则移动到下一个叶子页
  if (index_ >= leaf_->GetSize()) {
    page_id_t next_page_id = leaf_->GetNextPageId();
    // Unpin 当前页面
    buffer_pool_manager_->UnpinPage(page_id_, false);

    if (next_page_id == INVALID_PAGE_ID) {
      // 已经到达末尾
      page_id_ = INVALID_PAGE_ID;
      leaf_ = nullptr;
      index_ = 0;
    } else {
      // 移动到下一个叶子页
      page_id_ = next_page_id;
      Page *page = buffer_pool_manager_->FetchPage(page_id_);
      leaf_ = reinterpret_cast<LeafPage *>(page->GetData());
      index_ = 0;
    }
  }
  return *this;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator==(const IndexIterator &itr) const -> bool {
  return page_id_ == itr.page_id_ && index_ == itr.index_;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator!=(const IndexIterator &itr) const -> bool { return !(*this == itr); }

template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;

template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;

template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;

template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;

template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
