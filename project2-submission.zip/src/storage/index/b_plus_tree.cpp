#include <string>

#include "common/exception.h"
#include "common/logger.h"
#include "common/rid.h"
#include "storage/index/b_plus_tree.h"
#include "storage/page/header_page.h"

namespace bustub {
INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, BufferPoolManager *buffer_pool_manager, const KeyComparator &comparator,
                          int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      root_page_id_(INVALID_PAGE_ID),
      buffer_pool_manager_(buffer_pool_manager),
      comparator_(comparator),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size) {}

/*
 * Helper function to decide whether current b+tree is empty
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { return root_page_id_ == INVALID_PAGE_ID; }
/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result, Transaction *transaction) -> bool {
  result->clear();

  if (IsEmpty()) {
    return false;
  }

  LeafPage *leaf = FindLeafPageConcurrent(key, Operation::SEARCH, transaction, false);
  if (leaf == nullptr) {
    return false;
  }

  page_id_t leaf_page_id = leaf->GetPageId();

  bool found = false;
  int left = 0;
  int right = leaf->GetSize() - 1;
  while (left <= right) {
    int mid = (left + right) / 2;
    int cmp = comparator_(key, leaf->KeyAt(mid));
    if (cmp == 0) {
      result->push_back(leaf->ValueAt(mid));
      found = true;
      break;
    }
    if (cmp < 0) {
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }

  Page *page = buffer_pool_manager_->FetchPage(leaf_page_id);
  page->RUnlatch();
  buffer_pool_manager_->UnpinPage(leaf_page_id, false);
  buffer_pool_manager_->UnpinPage(leaf_page_id, false);
  return found;
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value, Transaction *transaction) -> bool {
  root_latch_.lock();
  if (IsEmpty()) {
    StartNewTree(key, value);
    root_latch_.unlock();
    return true;
  }
  root_latch_.unlock();

  LeafPage *leaf = FindLeafPageConcurrent(key, Operation::INSERT, transaction, false);
  if (leaf == nullptr) {
    return false;
  }

  page_id_t leaf_page_id = leaf->GetPageId();

  int new_size = InsertIntoLeaf(leaf, key, value);
  bool inserted = new_size != -1;

  Page *page = buffer_pool_manager_->FetchPage(leaf_page_id);


  if (!inserted) {
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    ReleaseAllLatches(transaction, false);
    return false;
  }

  if (new_size <= leaf->GetMaxSize()) {
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page_id, true);
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    ReleaseAllLatches(transaction, true);
    return true;
  }

  LeafPage *new_leaf = nullptr;
  KeyType push_up_key = SplitLeaf(leaf, &new_leaf);

  InsertIntoParent(reinterpret_cast<BPlusTreePage *>(leaf), push_up_key,
                   reinterpret_cast<BPlusTreePage *>(new_leaf));

  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(leaf_page_id, true);
  buffer_pool_manager_->UnpinPage(leaf_page_id, false);
  buffer_pool_manager_->UnpinPage(new_leaf->GetPageId(), true);
  ReleaseAllLatches(transaction, true);
  return true;
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key, Transaction *transaction) {
  if (IsEmpty()) {
    return;
  }

  LeafPage *leaf = FindLeafPageConcurrent(key, Operation::DELETE, transaction, false);
  if (leaf == nullptr) {
    return;
  }

  page_id_t leaf_page_id = leaf->GetPageId();

  bool found = false;
  for (int i = 0; i < leaf->GetSize(); i++) {
    if (comparator_(key, leaf->KeyAt(i)) == 0) {
      found = true;
      break;
    }
  }

  Page *page = buffer_pool_manager_->FetchPage(leaf_page_id);

  if (!found) {
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    ReleaseAllLatches(transaction, false);
    return;
  }

  RemoveEntry(reinterpret_cast<BPlusTreePage *>(leaf), key);


  if (leaf->IsRootPage()) {
    AdjustRoot(reinterpret_cast<BPlusTreePage *>(leaf));
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page_id, true);
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    ReleaseAllLatches(transaction, true);
    return;
  }

  if (leaf->GetSize() < leaf->GetMinSize()) {
    CoalesceOrRedistribute(reinterpret_cast<BPlusTreePage *>(leaf));
  }

  page->WUnlatch();
  buffer_pool_manager_->UnpinPage(leaf_page_id, true);
  buffer_pool_manager_->UnpinPage(leaf_page_id, false);
  ReleaseAllLatches(transaction, true);
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/*
 * Input parameter is void, find the leftmost leaf page first, then construct
 * index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE {
  if (IsEmpty()) {
    return INDEXITERATOR_TYPE(buffer_pool_manager_, INVALID_PAGE_ID, 0);
  }

  KeyType dummy_key;
  LeafPage *leaf = FindLeafPage(dummy_key, true);
  page_id_t leaf_page_id = leaf->GetPageId();
  buffer_pool_manager_->UnpinPage(leaf_page_id, false);

  return INDEXITERATOR_TYPE(buffer_pool_manager_, leaf_page_id, 0);
}

/*
 * Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
  if (IsEmpty()) {
    return INDEXITERATOR_TYPE(buffer_pool_manager_, INVALID_PAGE_ID, 0);
  }

  LeafPage *leaf = FindLeafPage(key, false);
  page_id_t leaf_page_id = leaf->GetPageId();

  int index = 0;
  int size = leaf->GetSize();
  for (int i = 0; i < size; i++) {
    if (comparator_(leaf->KeyAt(i), key) >= 0) {
      index = i;
      break;
    }
    index = i + 1;
  }

  if (index >= size) {
    page_id_t next_page_id = leaf->GetNextPageId();
    buffer_pool_manager_->UnpinPage(leaf_page_id, false);
    if (next_page_id == INVALID_PAGE_ID) {
      return INDEXITERATOR_TYPE(buffer_pool_manager_, INVALID_PAGE_ID, 0);
    }
    return INDEXITERATOR_TYPE(buffer_pool_manager_, next_page_id, 0);
  }

  buffer_pool_manager_->UnpinPage(leaf_page_id, false);
  return INDEXITERATOR_TYPE(buffer_pool_manager_, leaf_page_id, index);
}

/*
 * Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE {
  return INDEXITERATOR_TYPE(buffer_pool_manager_, INVALID_PAGE_ID, 0);
}

/**
 * @return Page id of the root of this tree
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() -> page_id_t { return root_page_id_; }

/*****************************************************************************
 * HELPER FUNCTIONS FOR SEARCH / INSERT
 *****************************************************************************/

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewTree(const KeyType &key, const ValueType &value) {
  page_id_t new_page_id;
  auto *page = buffer_pool_manager_->NewPage(&new_page_id);
  BUSTUB_ENSURE(page != nullptr, "Failed to allocate new page for B+ tree root");

  auto *leaf = reinterpret_cast<LeafPage *>(page->GetData());
  leaf->Init(new_page_id, INVALID_PAGE_ID, leaf_max_size_);

  MappingType *array =
      reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);
  array[0] = {key, value};
  leaf->SetSize(1);

  root_page_id_ = new_page_id;
  UpdateRootPageId(1);

  buffer_pool_manager_->UnpinPage(new_page_id, true);
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindLeafPage(const KeyType &key, bool left_most) -> LeafPage * {
  if (IsEmpty()) {
    return nullptr;
  }

  page_id_t cur_page_id = root_page_id_;
  while (true) {
    Page *page = buffer_pool_manager_->FetchPage(cur_page_id);
    BUSTUB_ENSURE(page != nullptr, "FetchPage returned nullptr in FindLeafPage");
    auto *node = reinterpret_cast<BPlusTreePage *>(page->GetData());

    if (node->IsLeafPage()) {
      return reinterpret_cast<LeafPage *>(node);
    }

    auto *internal = reinterpret_cast<InternalPage *>(node);
    int size = internal->GetSize();
    BUSTUB_ENSURE(size > 0, "Internal page size must be positive");

    int child_index = 0;
    if (left_most) {
      child_index = 0;
    } else {
      int i = 1;
      for (; i < size; i++) {
        if (comparator_(key, internal->KeyAt(i)) < 0) {
          break;
        }
      }
      child_index = i - 1;
    }
    page_id_t next_page_id = internal->ValueAt(child_index);

    buffer_pool_manager_->UnpinPage(cur_page_id, false);
    cur_page_id = next_page_id;
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsSafe(BPlusTreePage *node, Operation op) -> bool {
  if (op == Operation::SEARCH) {
    return true;
  }
  if (op == Operation::INSERT) {
    if (node->IsLeafPage()) {
      return node->GetSize() < node->GetMaxSize();
    }
    return node->GetSize() < node->GetMaxSize();
  }
  if (node->IsRootPage()) {
    if (node->IsLeafPage()) {
      return node->GetSize() > 1;
    }
    return node->GetSize() > 2;
  }
  return node->GetSize() > node->GetMinSize();
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ReleaseAllLatches(Transaction *transaction, bool is_dirty) {
  if (transaction == nullptr) {
    return;
  }
  auto page_set = transaction->GetPageSet();
  while (!page_set->empty()) {
    Page *page = page_set->front();
    page_set->pop_front();
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetPageId(), is_dirty);
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindLeafPageConcurrent(const KeyType &key, Operation op, Transaction *transaction, bool left_most)
    -> LeafPage * {
  root_latch_.lock();

  if (IsEmpty()) {
    root_latch_.unlock();
    return nullptr;
  }

  page_id_t cur_page_id = root_page_id_;
  Page *page = buffer_pool_manager_->FetchPage(cur_page_id);
  BUSTUB_ENSURE(page != nullptr, "FetchPage returned nullptr in FindLeafPageConcurrent");

  if (op == Operation::SEARCH) {
    page->RLatch();
  } else {
    page->WLatch();
  }
  root_latch_.unlock();

  while (true) {
    auto *node = reinterpret_cast<BPlusTreePage *>(page->GetData());

    if (node->IsLeafPage()) {
      return reinterpret_cast<LeafPage *>(node);
    }

    auto *internal = reinterpret_cast<InternalPage *>(node);
    int size = internal->GetSize();
    BUSTUB_ENSURE(size > 0, "Internal page size must be positive");

    int child_index = 0;
    if (left_most) {
      child_index = 0;
    } else {
      int i = 1;
      for (; i < size; i++) {
        if (comparator_(key, internal->KeyAt(i)) < 0) {
          break;
        }
      }
      child_index = i - 1;
    }
    page_id_t next_page_id = internal->ValueAt(child_index);

    Page *child_page = buffer_pool_manager_->FetchPage(next_page_id);
    BUSTUB_ENSURE(child_page != nullptr, "FetchPage returned nullptr for child in FindLeafPageConcurrent");

    if (op == Operation::SEARCH) {
      child_page->RLatch();
      page->RUnlatch();
      buffer_pool_manager_->UnpinPage(cur_page_id, false);
    } else {
      child_page->WLatch();
      if (IsSafe(reinterpret_cast<BPlusTreePage *>(child_page->GetData()), op)) {
        page->WUnlatch();
        buffer_pool_manager_->UnpinPage(cur_page_id, false);
        if (transaction != nullptr) {
          ReleaseAllLatches(transaction, false);
        }
      } else {
        if (transaction != nullptr) {
          transaction->AddIntoPageSet(page);
        }
      }
    }

    cur_page_id = next_page_id;
    page = child_page;
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::InsertIntoLeaf(LeafPage *leaf, const KeyType &key, const ValueType &value) -> int {
  int size = leaf->GetSize();

  int insert_pos = 0;
  while (insert_pos < size) {
    int cmp = comparator_(key, leaf->KeyAt(insert_pos));
    if (cmp == 0) {
      return -1;
    }
    if (cmp < 0) {
      break;
    }
    insert_pos++;
  }

  MappingType *array =
      reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);

  for (int i = size; i > insert_pos; i--) {
    array[i] = array[i - 1];
  }
  array[insert_pos] = {key, value};
  leaf->SetSize(size + 1);
  return leaf->GetSize();
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::SplitLeaf(LeafPage *leaf, LeafPage **new_leaf) -> KeyType {
  page_id_t new_page_id;
  Page *new_page = buffer_pool_manager_->NewPage(&new_page_id);
  BUSTUB_ENSURE(new_page != nullptr, "Failed to allocate new leaf page");

  auto *right_leaf = reinterpret_cast<LeafPage *>(new_page->GetData());
  right_leaf->Init(new_page_id, leaf->GetParentPageId(), leaf->GetMaxSize());

  int total_size = leaf->GetSize();
  int split_index = total_size / 2;
  int right_size = total_size - split_index;

  MappingType *left_array =
      reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);
  MappingType *right_array =
      reinterpret_cast<MappingType *>(reinterpret_cast<char *>(right_leaf) + LEAF_PAGE_HEADER_SIZE);

  for (int i = 0; i < right_size; i++) {
    right_array[i] = left_array[split_index + i];
  }

  leaf->SetSize(split_index);
  right_leaf->SetSize(right_size);

  right_leaf->SetNextPageId(leaf->GetNextPageId());
  leaf->SetNextPageId(new_page_id);

  *new_leaf = right_leaf;
  return right_array[0].first;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertIntoParent(BPlusTreePage *old_node, const KeyType &key, BPlusTreePage *new_node) {
  page_id_t parent_id = old_node->GetParentPageId();


  if (parent_id == INVALID_PAGE_ID) {
    page_id_t new_root_page_id;
    Page *new_root_page = buffer_pool_manager_->NewPage(&new_root_page_id);
    BUSTUB_ENSURE(new_root_page != nullptr, "Failed to allocate new internal root page");

    auto *new_root = reinterpret_cast<InternalPage *>(new_root_page->GetData());
    new_root->Init(new_root_page_id, INVALID_PAGE_ID, internal_max_size_);

    using InternalMappingType = std::pair<KeyType, page_id_t>;
    InternalMappingType *root_array =
        reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(new_root) + INTERNAL_PAGE_HEADER_SIZE);

    root_array[0].second = old_node->GetPageId();
    root_array[1].first = key;
    root_array[1].second = new_node->GetPageId();
    new_root->SetSize(2);

    old_node->SetParentPageId(new_root_page_id);
    new_node->SetParentPageId(new_root_page_id);

    root_page_id_ = new_root_page_id;
    UpdateRootPageId();

    buffer_pool_manager_->UnpinPage(new_root_page_id, true);
    return;
  }

  Page *parent_page = buffer_pool_manager_->FetchPage(parent_id);
  BUSTUB_ENSURE(parent_page != nullptr, "Parent page not found");

  auto *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());
  int parent_size = parent->GetSize();

  using InternalMappingType = std::pair<KeyType, page_id_t>;
  InternalMappingType *parent_array =
      reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(parent) + INTERNAL_PAGE_HEADER_SIZE);

  int insert_index = 0;
  while (insert_index < parent_size && parent_array[insert_index].second != old_node->GetPageId()) {
    insert_index++;
  }

  for (int i = parent_size; i > insert_index + 1; i--) {
    parent_array[i] = parent_array[i - 1];
  }

  parent_array[insert_index + 1].first = key;
  parent_array[insert_index + 1].second = new_node->GetPageId();
  parent->SetSize(parent_size + 1);

  new_node->SetParentPageId(parent_id);

  if (parent->GetSize() > parent->GetMaxSize()) {
    page_id_t new_internal_page_id;
    Page *new_internal_page = buffer_pool_manager_->NewPage(&new_internal_page_id);
    BUSTUB_ENSURE(new_internal_page != nullptr, "Failed to allocate new internal page for split");

    auto *new_internal = reinterpret_cast<InternalPage *>(new_internal_page->GetData());
    new_internal->Init(new_internal_page_id, parent->GetParentPageId(), internal_max_size_);

    int total_size = parent->GetSize();
    int split_index = total_size / 2;

    InternalMappingType *new_array =
        reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(new_internal) + INTERNAL_PAGE_HEADER_SIZE);

    KeyType push_up_key = parent_array[split_index].first;

    new_array[0].second = parent_array[split_index].second;
    int new_size = 1;
    for (int i = split_index + 1; i < total_size; i++) {
      new_array[new_size] = parent_array[i];
      new_size++;
    }
    new_internal->SetSize(new_size);
    parent->SetSize(split_index);

    for (int i = 0; i < new_size; i++) {
      Page *child_page = buffer_pool_manager_->FetchPage(new_array[i].second);
      auto *child_node = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
      child_node->SetParentPageId(new_internal_page_id);
      buffer_pool_manager_->UnpinPage(new_array[i].second, true);
    }

    InsertIntoParent(reinterpret_cast<BPlusTreePage *>(parent), push_up_key,
                     reinterpret_cast<BPlusTreePage *>(new_internal));

    buffer_pool_manager_->UnpinPage(new_internal_page_id, true);
    buffer_pool_manager_->UnpinPage(parent_id, true);
  } else {
    buffer_pool_manager_->UnpinPage(parent_id, true);
  }
}

/*****************************************************************************
 * DELETION HELPERS
 *****************************************************************************/

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveEntry(BPlusTreePage *node, const KeyType &key) {
  if (node->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(node);
    int size = leaf->GetSize();
    int delete_index = -1;
    for (int i = 0; i < size; i++) {
      if (comparator_(key, leaf->KeyAt(i)) == 0) {
        delete_index = i;
        break;
      }
    }
    if (delete_index == -1) {
      return;
    }

    MappingType *array =
        reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);
    for (int i = delete_index; i < size - 1; i++) {
      array[i] = array[i + 1];
    }
    leaf->SetSize(size - 1);
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(node);
    int size = internal->GetSize();
    using InternalMappingType = std::pair<KeyType, page_id_t>;
    InternalMappingType *array =
        reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(internal) + INTERNAL_PAGE_HEADER_SIZE);

    int delete_index = -1;
    for (int i = 1; i < size; i++) {
      if (comparator_(key, array[i].first) == 0) {
        delete_index = i;
        break;
      }
    }
    if (delete_index == -1) {
      return;
    }
    for (int i = delete_index; i < size - 1; i++) {
      array[i] = array[i + 1];
    }
    internal->SetSize(size - 1);
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::AdjustRoot(BPlusTreePage *root_node) {
  if (!root_node->IsRootPage()) {
    return;
  }

  if (root_node->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(root_node);
    if (leaf->GetSize() > 0) {
      return;
    }
    buffer_pool_manager_->DeletePage(leaf->GetPageId());
    root_page_id_ = INVALID_PAGE_ID;
    UpdateRootPageId();
    return;
  }

  auto *internal = reinterpret_cast<InternalPage *>(root_node);
  if (internal->GetSize() > 1) {
    return;
  }

  using InternalMappingType = std::pair<KeyType, page_id_t>;
  InternalMappingType *array =
      reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(internal) + INTERNAL_PAGE_HEADER_SIZE);
  page_id_t child_pid = array[0].second;

  root_page_id_ = child_pid;
  UpdateRootPageId();

  Page *child_page = buffer_pool_manager_->FetchPage(child_pid);
  auto *child_node = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
  child_node->SetParentPageId(INVALID_PAGE_ID);
  buffer_pool_manager_->UnpinPage(child_pid, true);

  buffer_pool_manager_->DeletePage(internal->GetPageId());
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::CoalesceOrRedistribute(BPlusTreePage *node) -> bool {
  if (node->IsRootPage()) {
    AdjustRoot(node);
    return false;
  }

  page_id_t parent_id = node->GetParentPageId();
  Page *parent_page = buffer_pool_manager_->FetchPage(parent_id);
  auto *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());

  using InternalMappingType = std::pair<KeyType, page_id_t>;
  InternalMappingType *parent_array =
      reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(parent) + INTERNAL_PAGE_HEADER_SIZE);
  int parent_size = parent->GetSize();

  int index_in_parent = 0;
  while (index_in_parent < parent_size && parent_array[index_in_parent].second != node->GetPageId()) {
    index_in_parent++;
  }

  int left_index = index_in_parent - 1;
  int right_index = index_in_parent + 1;
  BPlusTreePage *sibling = nullptr;
  page_id_t sibling_pid = INVALID_PAGE_ID;
  bool is_left_sibling = false;

  if (left_index >= 0) {
    sibling_pid = parent_array[left_index].second;
    is_left_sibling = true;
  } else if (right_index < parent_size) {
    sibling_pid = parent_array[right_index].second;
    is_left_sibling = false;
  }

  Page *sibling_page = buffer_pool_manager_->FetchPage(sibling_pid);
  sibling = reinterpret_cast<BPlusTreePage *>(sibling_page->GetData());

  int min_size = node->GetMinSize();

  if (sibling->GetSize() > min_size) {
    if (node->IsLeafPage()) {
      auto *leaf = reinterpret_cast<LeafPage *>(node);
      auto *sib_leaf = reinterpret_cast<LeafPage *>(sibling);
      MappingType *leaf_array =
          reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);
      MappingType *sib_array =
          reinterpret_cast<MappingType *>(reinterpret_cast<char *>(sib_leaf) + LEAF_PAGE_HEADER_SIZE);

      if (is_left_sibling) {
        for (int i = leaf->GetSize(); i > 0; i--) {
          leaf_array[i] = leaf_array[i - 1];
        }
        leaf_array[0] = sib_array[sib_leaf->GetSize() - 1];
        leaf->SetSize(leaf->GetSize() + 1);
        sib_leaf->SetSize(sib_leaf->GetSize() - 1);

        parent_array[index_in_parent].first = leaf_array[0].first;
      } else {
        leaf_array[leaf->GetSize()] = sib_array[0];
        leaf->SetSize(leaf->GetSize() + 1);
        for (int i = 0; i < sib_leaf->GetSize() - 1; i++) {
          sib_array[i] = sib_array[i + 1];
        }
        sib_leaf->SetSize(sib_leaf->GetSize() - 1);

        parent_array[right_index].first = sib_array[0].first;
      }
    } else {
      auto *internal = reinterpret_cast<InternalPage *>(node);
      auto *sib_internal = reinterpret_cast<InternalPage *>(sibling);
      using InternalMappingType = std::pair<KeyType, page_id_t>;
      InternalMappingType *array =
          reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(internal) + INTERNAL_PAGE_HEADER_SIZE);
      InternalMappingType *sib_array =
          reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(sib_internal) + INTERNAL_PAGE_HEADER_SIZE);

      if (is_left_sibling) {
        for (int i = internal->GetSize(); i > 0; i--) {
          array[i] = array[i - 1];
        }
        array[0].first = parent_array[index_in_parent].first;
        array[0].second = sib_array[sib_internal->GetSize() - 1].second;
        internal->SetSize(internal->GetSize() + 1);

        parent_array[index_in_parent].first = sib_array[sib_internal->GetSize() - 1].first;
        sib_internal->SetSize(sib_internal->GetSize() - 1);
      } else {
        array[internal->GetSize()].first = parent_array[right_index].first;
        array[internal->GetSize()].second = sib_array[0].second;
        internal->SetSize(internal->GetSize() + 1);

        parent_array[right_index].first = sib_array[1].first;
        for (int i = 0; i < sib_internal->GetSize() - 1; i++) {
          sib_array[i] = sib_array[i + 1];
        }
        sib_internal->SetSize(sib_internal->GetSize() - 1);
      }
    }

    buffer_pool_manager_->UnpinPage(parent_id, true);
    buffer_pool_manager_->UnpinPage(sibling_pid, true);
    return false;
  }

  if (node->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(node);
    auto *sib_leaf = reinterpret_cast<LeafPage *>(sibling);
    MappingType *leaf_array =
        reinterpret_cast<MappingType *>(reinterpret_cast<char *>(leaf) + LEAF_PAGE_HEADER_SIZE);
    MappingType *sib_array =
        reinterpret_cast<MappingType *>(reinterpret_cast<char *>(sib_leaf) + LEAF_PAGE_HEADER_SIZE);

    if (is_left_sibling) {
      for (int i = 0; i < leaf->GetSize(); i++) {
        sib_array[sib_leaf->GetSize() + i] = leaf_array[i];
      }
      sib_leaf->SetSize(sib_leaf->GetSize() + leaf->GetSize());
      sib_leaf->SetNextPageId(leaf->GetNextPageId());
    } else {
      for (int i = 0; i < sib_leaf->GetSize(); i++) {
        leaf_array[leaf->GetSize() + i] = sib_array[i];
      }
      leaf->SetSize(leaf->GetSize() + sib_leaf->GetSize());
      leaf->SetNextPageId(sib_leaf->GetNextPageId());
    }
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(node);
    auto *sib_internal = reinterpret_cast<InternalPage *>(sibling);
    using InternalMappingType = std::pair<KeyType, page_id_t>;
    InternalMappingType *array =
        reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(internal) + INTERNAL_PAGE_HEADER_SIZE);
    InternalMappingType *sib_array =
        reinterpret_cast<InternalMappingType *>(reinterpret_cast<char *>(sib_internal) + INTERNAL_PAGE_HEADER_SIZE);

    if (is_left_sibling) {
      sib_array[sib_internal->GetSize()].first = parent_array[index_in_parent].first;
      sib_array[sib_internal->GetSize()].second = array[0].second;
      for (int i = 1; i < internal->GetSize(); i++) {
        sib_array[sib_internal->GetSize() + i] = array[i];
      }
      sib_internal->SetSize(sib_internal->GetSize() + internal->GetSize());
      page_id_t sib_pid = sib_internal->GetPageId();
      for (int i = 0; i < internal->GetSize(); i++) {
        Page *child_page = buffer_pool_manager_->FetchPage(array[i].second);
        auto *child_node = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
        child_node->SetParentPageId(sib_pid);
        buffer_pool_manager_->UnpinPage(array[i].second, true);
      }
    } else {
      array[internal->GetSize()].first = parent_array[right_index].first;
      array[internal->GetSize()].second = sib_array[0].second;
      for (int i = 1; i < sib_internal->GetSize(); i++) {
        array[internal->GetSize() + i] = sib_array[i];
      }
      internal->SetSize(internal->GetSize() + sib_internal->GetSize());
      page_id_t internal_pid = internal->GetPageId();
      for (int i = 0; i < sib_internal->GetSize(); i++) {
        Page *child_page = buffer_pool_manager_->FetchPage(sib_array[i].second);
        auto *child_node = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
        child_node->SetParentPageId(internal_pid);
        buffer_pool_manager_->UnpinPage(sib_array[i].second, true);
      }
    }
  }

  KeyType remove_key =
      is_left_sibling ? parent_array[index_in_parent].first : parent_array[right_index].first;
  RemoveEntry(parent, remove_key);

  buffer_pool_manager_->UnpinPage(sibling_pid, true);
  buffer_pool_manager_->UnpinPage(parent_id, true);

  if (is_left_sibling) {
    buffer_pool_manager_->DeletePage(node->GetPageId());
  } else {
    buffer_pool_manager_->DeletePage(sibling->GetPageId());
  }

  return true;
}

/*****************************************************************************
 * UTILITIES AND DEBUG
 *****************************************************************************/
/*
 * Update/Insert root page id in header page(where page_id = 0, header_page is
 * defined under include/page/header_page.h)
 * Call this method everytime root page id is changed.
 * @parameter: insert_record      default value is false. When set to true,
 * insert a record <index_name, root_page_id> into header page instead of
 * updating it.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UpdateRootPageId(int insert_record) {
  auto *header_page = static_cast<HeaderPage *>(buffer_pool_manager_->FetchPage(HEADER_PAGE_ID));
  if (insert_record != 0) {
    // create a new record<index_name + root_page_id> in header_page
    header_page->InsertRecord(index_name_, root_page_id_);
  } else {
    // update root_page_id in header_page
    header_page->UpdateRecord(index_name_, root_page_id_);
  }
  buffer_pool_manager_->UnpinPage(HEADER_PAGE_ID, true);
}

/*
 * This method is used for test only
 * Read data from file and insert one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertFromFile(const std::string &file_name, Transaction *transaction) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;

    KeyType index_key;
    index_key.SetFromInteger(key);
    RID rid(key);
    Insert(index_key, rid, transaction);
  }
}
/*
 * This method is used for test only
 * Read data from file and remove one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveFromFile(const std::string &file_name, Transaction *transaction) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;
    KeyType index_key;
    index_key.SetFromInteger(key);
    Remove(index_key, transaction);
  }
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Draw(BufferPoolManager *bpm, const std::string &outf) {
  if (IsEmpty()) {
    LOG_WARN("Draw an empty tree");
    return;
  }
  std::ofstream out(outf);
  out << "digraph G {" << std::endl;
  ToGraph(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(root_page_id_)->GetData()), bpm, out);
  out << "}" << std::endl;
  out.flush();
  out.close();
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Print(BufferPoolManager *bpm) {
  if (IsEmpty()) {
    LOG_WARN("Print an empty tree");
    return;
  }
  ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(root_page_id_)->GetData()), bpm);
}

/**
 * This method is used for debug only, You don't need to modify
 * @tparam KeyType
 * @tparam ValueType
 * @tparam KeyComparator
 * @param page
 * @param bpm
 * @param out
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const {
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    // Print node name
    out << leaf_prefix << leaf->GetPageId();
    // Print node properties
    out << "[shape=plain color=green ";
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << leaf->GetPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
        << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < leaf->GetSize(); i++) {
      out << "<TD>" << leaf->KeyAt(i) << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Leaf node link if there is a next page
    if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
      out << leaf_prefix << leaf->GetPageId() << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
      out << "{rank=same " << leaf_prefix << leaf->GetPageId() << " " << leaf_prefix << leaf->GetNextPageId() << "};\n";
    }

    // Print parent links if there is a parent
    if (leaf->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << leaf->GetParentPageId() << ":p" << leaf->GetPageId() << " -> " << leaf_prefix
          << leaf->GetPageId() << ";\n";
    }
  } else {
    auto *inner = reinterpret_cast<InternalPage *>(page);
    // Print node name
    out << internal_prefix << inner->GetPageId();
    // Print node properties
    out << "[shape=plain color=pink ";  // why not?
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << inner->GetPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
        << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < inner->GetSize(); i++) {
      out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
      if (i > 0) {
        out << inner->KeyAt(i);
      } else {
        out << " ";
      }
      out << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Parent link
    if (inner->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << inner->GetParentPageId() << ":p" << inner->GetPageId() << " -> " << internal_prefix
          << inner->GetPageId() << ";\n";
    }
    // Print leaves
    for (int i = 0; i < inner->GetSize(); i++) {
      auto child_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i))->GetData());
      ToGraph(child_page, bpm, out);
      if (i > 0) {
        auto sibling_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i - 1))->GetData());
        if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
          out << "{rank=same " << internal_prefix << sibling_page->GetPageId() << " " << internal_prefix
              << child_page->GetPageId() << "};\n";
        }
        bpm->UnpinPage(sibling_page->GetPageId(), false);
      }
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

/**
 * This function is for debug only, you don't need to modify
 * @tparam KeyType
 * @tparam ValueType
 * @tparam KeyComparator
 * @param page
 * @param bpm
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    std::cout << "Leaf Page: " << leaf->GetPageId() << " parent: " << leaf->GetParentPageId()
              << " next: " << leaf->GetNextPageId() << std::endl;
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(page);
    std::cout << "Internal Page: " << internal->GetPageId() << " parent: " << internal->GetParentPageId() << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(internal->ValueAt(i))->GetData()), bpm);
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
