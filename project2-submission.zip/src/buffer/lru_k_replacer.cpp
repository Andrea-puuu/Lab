//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <mutex>
#include <limits>

#include "buffer/lru_k_replacer.h"
#include "common/macros.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {
  BUSTUB_ASSERT(num_frames > 0, "Number of frames must be greater than 0");
  BUSTUB_ASSERT(k > 0, "K must be greater than 0");
}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (curr_size_ == 0) {
    return false;
  }

  frame_id_t victim_frame = -1;
  size_t max_backward_distance = 0;
  size_t earliest_access_time = std::numeric_limits<size_t>::max();
  bool found_inf_distance_frame = false;
  
  // 遍历所有帧，寻找最佳的驱逐候选
  for (const auto &frame_pair : frame_info_) {
    const auto &fid = frame_pair.first;
    const auto &info = frame_pair.second;
    
    // 只考虑可驱逐的帧
    if (!info.evictable) {
      continue;
    }
    
    // 跳过没有访问记录的帧
    if (info.access_timestamps.empty()) {
      continue;
    }
    
    // 计算后退k距离
    if (info.access_timestamps.size() < k_) {
      // 访问次数少于k次，视为+inf
      if (!found_inf_distance_frame) {
        // 第一次找到+inf帧
        victim_frame = fid;
        earliest_access_time = info.access_timestamps.front();
        found_inf_distance_frame = true;
      } else {
        // 已经找到+inf帧，比较最早访问时间
        if (info.access_timestamps.front() < earliest_access_time) {
          victim_frame = fid;
          earliest_access_time = info.access_timestamps.front();
        }
      }
    } else if (!found_inf_distance_frame) {
      // 访问次数大于等于k次，计算真实的后退k距离
      // 后退k距离 = 当前时间戳 - 第k个最近访问的时间戳
      size_t kth_access_timestamp = info.access_timestamps[info.access_timestamps.size() - k_];
      size_t backward_distance = current_timestamp_ - kth_access_timestamp;
      
      if (victim_frame == -1 || backward_distance > max_backward_distance) {
        max_backward_distance = backward_distance;
        victim_frame = fid;
      } else if (backward_distance == max_backward_distance && victim_frame != -1) {
        // 后退距离相同，选择最后一次访问时间最早的
        if (info.last_access_timestamp < frame_info_[victim_frame].last_access_timestamp) {
          victim_frame = fid;
        }
      }
    }
  }
  
  if (victim_frame != -1) {
    // 找到受害者帧，移除它
    frame_info_.erase(victim_frame);
    curr_size_--;
    *frame_id = victim_frame;
    return true;
  }
  
  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);
  
  // 检查帧ID是否有效
  BUSTUB_ASSERT(static_cast<size_t>(frame_id) < replacer_size_, "Frame ID exceeds replacer size");
  
  // 增加时间戳
  current_timestamp_++;
  
  // 确保帧信息存在
  if (frame_info_.find(frame_id) == frame_info_.end()) {
    frame_info_[frame_id] = FrameInfo();
  }
  
  FrameInfo &info = frame_info_[frame_id];
  
  // 更新访问时间戳列表
  info.access_timestamps.push_back(current_timestamp_);
  info.last_access_timestamp = current_timestamp_;
  
  // 如果访问时间戳超过k个，删除最早的
  if (info.access_timestamps.size() > k_) {
    info.access_timestamps.erase(info.access_timestamps.begin());
  }
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::lock_guard<std::mutex> lock(latch_);
  
  // 检查帧ID是否有效
  BUSTUB_ASSERT(static_cast<size_t>(frame_id) < replacer_size_, "Frame ID exceeds replacer size");
  
  // 确保帧信息存在
  if (frame_info_.find(frame_id) == frame_info_.end()) {
    return;
  }
  
  FrameInfo &info = frame_info_[frame_id];
  
  // 如果状态发生变化，更新当前大小
  if (info.evictable != set_evictable) {
    info.evictable = set_evictable;
    if (set_evictable) {
      curr_size_++;
    } else {
      curr_size_--;
    }
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);
  
  // 检查帧是否存在
  if (frame_info_.find(frame_id) == frame_info_.end()) {
    return;
  }
  
  const FrameInfo &info = frame_info_[frame_id];
  
  // 检查帧是否可被移除
  BUSTUB_ASSERT(info.evictable, "Cannot remove non-evictable frame");
  
  // 移除帧
  frame_info_.erase(frame_id);
  curr_size_--;
}

auto LRUKReplacer::Size() -> size_t {
  std::lock_guard<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub
