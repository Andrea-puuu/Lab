//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// extendible_hash_table.cpp
//
// Identification: src/container/hash/extendible_hash_table.cpp
//
// Copyright (c) 2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cassert>
#include <cstdlib>
#include <functional>
#include <list>
#include <utility>

#include "container/hash/extendible_hash_table.h"
#include "storage/page/page.h"

namespace bustub {

template <typename K, typename V>
ExtendibleHashTable<K, V>::ExtendibleHashTable(size_t bucket_size) : bucket_size_(bucket_size) {
  // 初始化目录，创建一个空桶
  dir_.resize(1);
  dir_[0] = std::make_shared<Bucket>(bucket_size);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::IndexOf(const K &key) -> size_t {
  int mask = (1 << global_depth_) - 1;
  return std::hash<K>()(key) & mask;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepth() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetGlobalDepthInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepthInternal() const -> int {
  return global_depth_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepth(int dir_index) const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetLocalDepthInternal(dir_index);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepthInternal(int dir_index) const -> int {
  return dir_[dir_index]->GetDepth();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBuckets() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetNumBucketsInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBucketsInternal() const -> int {
  return num_buckets_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Find(const K &key, V &value) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  size_t idx = IndexOf(key);
  return dir_[idx]->Find(key, value);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Remove(const K &key) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  size_t idx = IndexOf(key);
  return dir_[idx]->Remove(key);
}

template <typename K, typename V>
void ExtendibleHashTable<K, V>::Insert(const K &key, const V &value) {
  std::scoped_lock<std::mutex> lock(latch_);

  while (true) {
    size_t idx = IndexOf(key);
    auto bucket = dir_[idx];

    // 尝试插入，如果成功则返回
    if (bucket->Insert(key, value)) {
      return;
    }

    // 桶已满，需要拆分
    // 如果局部深度等于全局深度，需要扩展目录
    if (bucket->GetDepth() == global_depth_) {
      // 扩展目录
      size_t old_size = dir_.size();
      dir_.resize(old_size * 2);
      // 复制现有指针
      for (size_t i = 0; i < old_size; i++) {
        dir_[i + old_size] = dir_[i];
      }
      global_depth_++;
    }

    // 创建新桶
    auto new_bucket = std::make_shared<Bucket>(bucket_size_, bucket->GetDepth() + 1);
    num_buckets_++;

    // 增加原桶的局部深度
    bucket->IncrementDepth();

    // 重新分配目录指针和数据
    int local_depth = bucket->GetDepth();
    size_t split_mask = 1ULL << (local_depth - 1);

    // 收集原桶中的所有项
    auto &items = bucket->GetItems();
    std::list<std::pair<K, V>> old_items(items.begin(), items.end());
    items.clear();

    // 重新分配目录指针
    for (size_t i = 0; i < dir_.size(); i++) {
      if (dir_[i] == bucket) {
        // 根据最新的位确定指针指向
        if ((i & split_mask) != 0) {
          dir_[i] = new_bucket;
        }
      }
    }

    // 重新分配原桶中的项
    for (const auto &item : old_items) {
      size_t new_idx = std::hash<K>()(item.first) & ((1ULL << local_depth) - 1);
      if ((new_idx & split_mask) != 0) {
        new_bucket->Insert(item.first, item.second);
      } else {
        bucket->Insert(item.first, item.second);
      }
    }
  }
}

//===--------------------------------------------------------------------===//
// Bucket
//===--------------------------------------------------------------------===//
template <typename K, typename V>
ExtendibleHashTable<K, V>::Bucket::Bucket(size_t array_size, int depth) : size_(array_size), depth_(depth) {}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Find(const K &key, V &value) -> bool {
  for (auto &item : list_) {
    if (item.first == key) {
      value = item.second;
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Remove(const K &key) -> bool {
  for (auto it = list_.begin(); it != list_.end(); it++) {
    if (it->first == key) {
      list_.erase(it);
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Insert(const K &key, const V &value) -> bool {
  // 检查键是否已存在
  for (auto &item : list_) {
    if (item.first == key) {
      item.second = value;
      return true;
    }
  }

  // 检查桶是否已满
  if (IsFull()) {
    return false;
  }

  // 插入新的键值对
  list_.emplace_back(key, value);
  return true;
}

template class ExtendibleHashTable<page_id_t, Page *>;
template class ExtendibleHashTable<Page *, std::list<Page *>::iterator>;
template class ExtendibleHashTable<int, int>;
// test purpose
template class ExtendibleHashTable<int, std::string>;
template class ExtendibleHashTable<int, std::list<int>::iterator>;

}  // namespace bustub
